
<!doctype html>
<html lang="en">
  <head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Dashboard - HjP</title>

	<!-- Bootstrap CSS-->
	<link rel="stylesheet" href="assets/modules/bootstrap-5.1.3/css/bootstrap.css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="assets/css/button.css">
	<!-- FontAwesome CSS-->
	<link rel="stylesheet" href="assets/modules/fontawesome6.1.1/css/all.css">
	<!-- Boxicons CSS-->
	<link rel="stylesheet" href="assets/modules/boxicons/css/boxicons.min.css">
	<!-- Apexcharts  CSS -->
	<link rel="stylesheet" href="assets/modules/apexcharts/new_apexcharts.css">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
	<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Include the Canvas library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	
	<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<style>
		.wrapper {
  --font-color-dark: #fefefe;
  --font-color-light: #111;
  --bg-color: #25396f;
  --main-color: #fefefe;
  position: relative;
  width: 300px;
  height: 36px;
  background-color: var(--bg-color);
  border: 2px solid var(--main-color);
  border-radius: 34px;
  display: flex;
  flex-direction: row;
  box-shadow: 4px 4px var(--main-color);
}

.option {
  width: 80.5px;
  height: 28px;
  position: relative;
  top: 2px;
  left: 2px;
}

.toggle_input {
  width: 100%;
  height: 100%;
  position: absolute;
  left: 0;
  top: 0;
  appearance: none;
  cursor: pointer;
}

.toggle_btn {
  width: 100%;
  height: 100%;
  background-color: var(--bg-color);
  border-radius: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.span {
  color: var(--font-color-dark);
}

.toggle_input:checked + .toggle_btn {
  background-color: var(--main-color);
}

.toggle_input:checked + .toggle_btn .span {
  color: var(--font-color-light);
}

.apexcharts-toolbar{
	display:none !important;
}




.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 20px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #b1b9c3;
  -webkit-transition: 0.4s;
  transition: 0.4s;
}

.slider:before {
  position: absolute;
  content: '';
  height: 30px;
  width: 30px;
  bottom: -5px;
  background: #18333E;
  -webkit-transition: 0.4s;
  transition: 0.4s;
}

.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}

input:checked+.slider {
  background-color: #b1b9c3;
}

input:checked+.slider:before {
  -webkit-transform: translateX(35px);
  -ms-transform: translateX(35px);
  transform: translateX(35px);
  background: #25396f;
}




	</style>
</head>
<body>
  
  <!--Topbar -->
  <div class="topbar transition">
	<div class="bars">
		<button type="button" class="btn transition" id="sidebar-toggle">
			<i class="fa fa-bars"></i>
		</button>
	</div>
		<div class="menu">
		
			<ul>
			
				<li class="nav-item dropdown dropdown-list-toggle">
						  
				  </li>
			 
				  <li class="nav-item dropdown">
					<a class="nav-link" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
					  <img src="assets/images/avatar/avatar-1.png" alt="">
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="my-profile.php"><i class="fa fa-user size-icon-1"></i> <span>My Profile</span></a>
						<a class="dropdown-item" href="settings.html"><i class="fa fa-cog size-icon-1"></i> <span>Settings</span></a>
						<hr class="dropdown-divider">
						<a class="dropdown-item" href="#"><i class="fa fa-sign-out-alt  size-icon-1"></i> <span>My Profile</span></a>
					</ul>
				  </li>
			</ul>
		</div>
	</div>

	
	<div class="sidebar transition overlay-scrollbars animate__animated  animate__slideInLeft">
        <div class="sidebar-content"> 
        	<div id="sidebar">
			
			
			<div class="logo">
					<h2 class="mb-0"><img src="assets/images/logo.png"> HjP</h2>
			</div>

            <ul class="side-menu">
                <li>
					<a href="index.php" class="active">
						<i class='bx bxs-dashboard icon' ></i> Dashboard
					</a>
				</li>

				
                <li class="divider" data-text="STARTER">Equipments Rent</li>
				
				<li>
					<a href="rent_list.php">
					<i class='bx bx-list-ul icon'></i>
						Pending Lists
					</a>
				</li>


				<li>
					<a href="approve_list.php">
					<i class='bx bx-list-ul icon'></i>
						Approved Lists
					</a>
				</li>

				<li>
					<a href="paid_list.php">
					<i class='bx bx-list-ul icon'></i>
						Paid Lists
					</a>
				</li>

				<li>
					<a href="completed_list.php">
					<i class='bx bx-list-ul icon'></i>
						Completed
					</a>
				</li>

				<li>
					<a href="cancelled_list.php">
					<i class='bx bx-list-ul icon'></i>
						Cancelled Lists
					</a>
				</li>

				
				<li class="divider" data-text="Atrana">Orders</li>

				<li>
					<a href="pending_orders.php">
					<i class='bx bx-list-ul icon'></i>
						Pending orders
					</a>
				</li>

				<li>
					<a href="prepaired_orders.php" >
					<i class='bx bx-list-ul icon'></i>
						Prepaired orders
					</a>
				</li>
				<li>
					<a href="on_delivery_orders.php" >
					<i class='bx bx-list-ul icon'></i>
						On Delivery orders
					</a>
				</li>

				<li>
					<a href="completed_orders.php" >
					<i class='bx bx-list-ul icon'></i>
						Completed Orders
					</a>
				</li>
				<li>
					<a href="cancelled_orders.php">
					<i class='bx bx-list-ul icon'></i>
						Cancelled Orders
					</a>
				</li>

				<li class="divider" data-text="Atrana">Equipments & Aggregates</li>
				<li>
					<a href="equipment_list.php">
					<i class='bx bx-list-ul icon'></i>
						Equipment Lists
					</a>
				</li>

				<li>
					<a href="sand_list.php">
					<i class='bx bx-list-ul icon'></i>
						Sand  Lists
					</a>
				</li>

            


				<li class="divider" data-text="Pages">Manage</li>

				<li>
                    <a href="#">
						<i class='bx bxs-user icon' ></i> 
						Account 
						<i class='bx bx-chevron-right icon-right' ></i>
					</a>
                    <ul class="side-dropdown">
                        <li><a href="my-profile.php">My Profile</a></li>
                        <li><a href="auth-reset-password.php">Reset Password</a></li>
						<li><a href="logout.php">Logout</a></li>
                    </ul>
                </li>

			


            </ul>
			
        </div>

       </div> 
	 </div>
    </div>

	<?php include "generate_report_modal.php";?>

	<div class="sidebar-overlay"></div>


	<!--Content Start-->
	<div class="content-start transition">
		<div class="container-fluid dashboard">
			
			<div class="content-header">
				<h1>Dashboard</h1>
				
			</div>
			<div class="wrapper">
  <div class="option">
    <input checked="" value="option1" name="toggle_btn" type="radio" id="today" class="toggle_input">
    <div class="toggle_btn">
      <span class="span">Today</span>
    </div>
  </div>
  <div class="option">
    <input value="option2" name="toggle_btn" type="radio" id="monthly" class="toggle_input">
    <div class="toggle_btn">
      <span class="span">Monthly</span>
    </div>  </div>
  <div class="option">
    <input value="option3" name="toggle_btn" type="radio" id="yearly" class="toggle_input">
    <div class="toggle_btn">
      <span class="span">Yearly</span>
    </div>  
  </div>
  <div class="option">
    <input value="option4" name="toggle_btn" type="radio" id="overall" class="toggle_input">
    <div class="toggle_btn">
      <span class="span">Overall</span>
    </div>  
  </div>
</div>

			<br>
			

			<div class="row">

			<div class="col-md-6 col-lg-3" id="today_revenue" style="display:block;">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col-4 d-flex align-items-center">
								<img src="wheel-bulldozer.png" alt="" height="60" width="60">
								</div>
								<div class="col-8">
<p>Today</p> <?php
// Set the default time zone to the Philippines
date_default_timezone_set('Asia/Manila');

// Include your database connection file
include "conn.php";

// Get today's date
$today_revenue = date("Y-m-d");

// Calculate yesterday's date
$yesterday_revenue = date("Y-m-d", strtotime("-1 day", strtotime($today_revenue)));

// Query to calculate total revenue for today
$query_revenue_today = "SELECT IFNULL(SUM(total), 0) as total_revenue_today FROM rental WHERE DATE(paid_date) = '$today_revenue' AND paid_status = 'Paid'";
$result_revenue_today = mysqli_query($conn, $query_revenue_today);

// Check if query executed successfully
if (!$result_revenue_today) {
    die('Error fetching today\'s revenue: ' . mysqli_error($conn));
}

$row_revenue_today = mysqli_fetch_assoc($result_revenue_today);
$total_revenue_today = $row_revenue_today['total_revenue_today'];

// Query to calculate total revenue for yesterday
$query_revenue_yesterday = "SELECT IFNULL(SUM(total), 0) as total_revenue_yesterday FROM rental WHERE DATE(paid_date) = '$yesterday_revenue' AND paid_status = 'Paid'";
$result_revenue_yesterday = mysqli_query($conn, $query_revenue_yesterday);

// Check if query executed successfully
if (!$result_revenue_yesterday) {
    die('Error fetching yesterday\'s revenue: ' . mysqli_error($conn));
}

$row_revenue_yesterday = mysqli_fetch_assoc($result_revenue_yesterday);
$total_revenue_yesterday = $row_revenue_yesterday['total_revenue_yesterday'];

// Close the database connection
mysqli_close($conn);

// Calculate percentage change
if ($total_revenue_yesterday != 0) {
    $percentage_change = (($total_revenue_today - $total_revenue_yesterday) / $total_revenue_yesterday) * 100;
} else {
    // Handle the case when yesterday's revenue is zero
    $percentage_change = ($total_revenue_today != 0) ? $total_revenue_today : 0; // Set to today's revenue if today's revenue is positive and yesterday's is zero, otherwise 0%
}

$percentage_change = round($percentage_change);


$sign = ($percentage_change >= 0) ? '+' : '-';

$class = ($percentage_change >= 0) ? 'text-success' : 'text-danger';

echo '<span class="' . $class . ' small pt-1 fw-bold" style="color:black; float:right; margin-top:2%;  font-size:0.8rem;" id="rent_percentage_today">' . $sign . abs($percentage_change) . '%</span>';

echo '<h5 id="rent_sales_today" style="font-size:1.1rem;">₱' . number_format($total_revenue_today, 0) . '</h5>';

?>

									
								</div>
							</div>
						</div>
					</div>
				</div>

					<?php include "cards/monthly_rent_revenue.php";?>
					<?php include "cards/yearly_rent_revenue.php";?>
					<?php include "cards/overall_rent_revenue.php";?>
				

				<div class="col-md-6 col-lg-3" id="today_orders_revenue" style="display:block;">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col-4 d-flex align-items-center">
									
									<img src="dunes.png" alt="" height="60" width="60">
								</div>
								<div class="col-8">
									<p>Today</p>
									<?php
// Set the default time zone to the Philippines
date_default_timezone_set('Asia/Manila');

// Include your database connection file
include "conn.php";

// Get today's date
$today_revenue = date("Y-m-d");

// Calculate yesterday's date
$yesterday_revenue = date("Y-m-d", strtotime("-1 day", strtotime($today_revenue)));

// Query to calculate total revenue for today
$query_revenue_today = "SELECT IFNULL(SUM(total), 0) as total_revenue_today FROM orders WHERE DATE(completed_date) = '$today_revenue' AND status = 'Completed'";
$result_revenue_today = mysqli_query($conn, $query_revenue_today);

// Check if query executed successfully
if (!$result_revenue_today) {
    die('Error fetching today\'s revenue: ' . mysqli_error($conn));
}

$row_revenue_today = mysqli_fetch_assoc($result_revenue_today);
$total_revenue_today = $row_revenue_today['total_revenue_today'];

// Query to calculate total revenue for yesterday
$query_revenue_yesterday = "SELECT IFNULL(SUM(total), 0) as total_revenue_yesterday FROM orders WHERE DATE(completed_date) = '$yesterday_revenue' AND status = 'Completed'";
$result_revenue_yesterday = mysqli_query($conn, $query_revenue_yesterday);

// Check if query executed successfully
if (!$result_revenue_yesterday) {
    die('Error fetching yesterday\'s revenue: ' . mysqli_error($conn));
}

$row_revenue_yesterday = mysqli_fetch_assoc($result_revenue_yesterday);
$total_revenue_yesterday = $row_revenue_yesterday['total_revenue_yesterday'];

// Close the database connection
mysqli_close($conn);

// Calculate percentage change
if ($total_revenue_yesterday != 0) {
    $percentage_change = (($total_revenue_today - $total_revenue_yesterday) / $total_revenue_yesterday) * 100;
} else {
    // Handle the case when yesterday's revenue is zero
    $percentage_change = ($total_revenue_today != 0) ? $total_revenue_today : 0; // Set to today's revenue if today's revenue is positive and yesterday's is zero, otherwise 0%
}

$percentage_change = round($percentage_change);


$sign = ($percentage_change >= 0) ? '+' : '-';

$class = ($percentage_change >= 0) ? 'text-success' : 'text-danger';

echo '<span class="' . $class . ' small pt-1 fw-bold" style="color:black; float:right;margin-top:2.8%; font-size:0.8rem;" id="orders_percentage_today">' . $sign . abs($percentage_change) . '%</span>';

echo '<h5 id="orders_sales_today" style="font-size:1.1rem;">₱' . number_format($total_revenue_today, 0) . '</h5>';

?>
								</div>
							</div>
						</div>
					</div>
				</div>

				<?php include "cards/monthly_orders_revenue.php";?>
				<?php include "cards/overall_orders_revenue.php";?>
				<?php include "cards/yearly_orders_revenue.php";?>

				<div class="col-md-6 col-lg-3" id="today_overall_sales" style="display:block;">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col-4 d-flex align-items-center">
								<img src="philippine-peso.png" alt="" height="60" width="60">
								</div>
								<div class="col-8" >
									<p>Sales Today</p>
									
									<?php
// Include your database connection file
include "conn.php";

date_default_timezone_set('Asia/Manila');

// Get today's date
$today_revenue = date("Y-m-d");

// Calculate yesterday's date
$yesterday_revenue = date("Y-m-d", strtotime("-1 day", strtotime($today_revenue)));

// Query to calculate total revenue for today from orders
$query_revenue_today_orders = "SELECT IFNULL(SUM(total), 0) as total_revenue_today FROM orders WHERE DATE(completed_date) = '$today_revenue' AND status = 'Completed'";
$result_revenue_today_orders = mysqli_query($conn, $query_revenue_today_orders);

// Check if query executed successfully for orders
if (!$result_revenue_today_orders) {
    die('Error fetching today\'s revenue from orders: ' . mysqli_error($conn));
}

$row_revenue_today_orders = mysqli_fetch_assoc($result_revenue_today_orders);
$total_revenue_today_orders = $row_revenue_today_orders['total_revenue_today'];

// Query to calculate total revenue for yesterday from orders
$query_revenue_yesterday_orders = "SELECT IFNULL(SUM(total), 0) as total_revenue_yesterday FROM orders WHERE DATE(completed_date) = '$yesterday_revenue' AND status = 'Completed'";
$result_revenue_yesterday_orders = mysqli_query($conn, $query_revenue_yesterday_orders);

// Check if query executed successfully for orders
if (!$result_revenue_yesterday_orders) {
    die('Error fetching yesterday\'s revenue from orders: ' . mysqli_error($conn));
}

$row_revenue_yesterday_orders = mysqli_fetch_assoc($result_revenue_yesterday_orders);
$total_revenue_yesterday_orders = $row_revenue_yesterday_orders['total_revenue_yesterday'];

// Query to calculate total revenue for today from rental
$query_revenue_today_rental = "SELECT IFNULL(SUM(total), 0) as total_revenue_today FROM rental WHERE DATE(paid_date) = '$today_revenue' AND paid_status = 'Paid'";
$result_revenue_today_rental = mysqli_query($conn, $query_revenue_today_rental);

// Check if query executed successfully for rental
if (!$result_revenue_today_rental) {
    die('Error fetching today\'s revenue from rental: ' . mysqli_error($conn));
}

$row_revenue_today_rental = mysqli_fetch_assoc($result_revenue_today_rental);
$total_revenue_today_rental = $row_revenue_today_rental['total_revenue_today'];

// Query to calculate total revenue for yesterday from rental
$query_revenue_yesterday_rental = "SELECT IFNULL(SUM(total), 0) as total_revenue_yesterday FROM rental WHERE DATE(paid_date) = '$yesterday_revenue' AND paid_status = 'Paid'";
$result_revenue_yesterday_rental = mysqli_query($conn, $query_revenue_yesterday_rental);

// Check if query executed successfully for rental
if (!$result_revenue_yesterday_rental) {
    die('Error fetching yesterday\'s revenue from rental: ' . mysqli_error($conn));
}

$row_revenue_yesterday_rental = mysqli_fetch_assoc($result_revenue_yesterday_rental);
$total_revenue_yesterday_rental = $row_revenue_yesterday_rental['total_revenue_yesterday'];

// Close the database connection
mysqli_close($conn);

// Compute total revenue for today
$total_revenue_today = $total_revenue_today_orders + $total_revenue_today_rental;

// Compute total revenue for yesterday
$total_revenue_yesterday = $total_revenue_yesterday_orders + $total_revenue_yesterday_rental;

// Calculate percentage change
if ($total_revenue_yesterday != 0) {
    $percentage_change = (($total_revenue_today - $total_revenue_yesterday) / $total_revenue_yesterday) * 100;
} else {
    // Handle the case when yesterday's revenue is zero
    $percentage_change = ($total_revenue_today != 0) ? $total_revenue_today : 0; // Set to today's revenue if today's revenue is positive and yesterday's is zero, otherwise 0%
}

$percentage_change = round($percentage_change);

$sign = ($percentage_change >= 0) ? '+' : '-';
$class = ($percentage_change >= 0) ? 'text-success' : 'text-danger';

echo '<div id="overall_sales_data">';

echo '<span class="' . $class . ' small pt-1 fw-bold" style="color:black; float:right; margin-top:7%; font-size:0.8rem;" id="overall_percentage_today">' . $sign . abs($percentage_change) . '%</span>';

// Display total revenue for today
echo '<h5 id="overall_sales_today" style="font-size:1.1rem;">₱' . number_format($total_revenue_today, 0) . '</h5>';
echo '</div>';
?>

								</div>
							</div>
						</div>
					</div>
				</div>

				<?php include "cards/monthly_overall_sales.php";?>
				<?php include "cards/yearly_overall_sales.php";?>
				<?php include "cards/overall_sales.php";?>


				<div class="col-md-6 col-lg-3" id="ratings_card">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col-4 d-flex align-items-center">
								<img src="rating.png" alt="" height="60" width="60">
								</div>
								<div class="col-8">
									<p>Overall Ratings</p>
									
									<?php
    // Connect to your MySQL database
    include "conn.php";

    // Query to calculate average rating
    $sql = "SELECT AVG(ratings) AS average_rating FROM feedbacks_tbl";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output average rating
        $row = $result->fetch_assoc();
        $average_rating = $row["average_rating"];
        // Format the average rating to have only one decimal place
        $formatted_average_rating = number_format($average_rating, 1);

        // Determine indication and color based on average rating
        $indication = "";
        $color = "";
        if ($average_rating >= 0 && $average_rating <= 1.5) {
            $indication = "Please Improve";
            $color = "red";
        } elseif ($average_rating > 1.5 && $average_rating <= 2.5) {
            $indication = "Moderate";
            $color = "yellow";
        } elseif ($average_rating > 2.5 && $average_rating <= 3.5) {
            $indication = "Good";
            $color = "green";
        } else {
            $indication = "Great!";
            $color = "green";
        }

        echo "<span style=\"float:right; margin-top:7%; color:$color;\">$indication</span>";
        echo "<h5>$formatted_average_rating / 5</h5>";
    } else {
        echo "0 results";
    }

    $conn->close();
?>


								</div>
							</div>
						</div>
					</div>

				</div>

				<div class="col-md-6">
						
					<div class="card">
						<div class="card-header">
							<h4 style="display:none;" id="sand_monthly_sales">Sand & Gravel Monthly Sales</h4>
							<h4 style="display:block;" id="he_monthly_sales">Heavy Equipments Monthly Sales</h4>

							<div class="theme_switcher">
  							<label id="switch" class="switch">
    						<input type="checkbox" id="toggle-sales-monthly"><span class="slider round"></span>
  						</label>
						</div>
						</div>
						<div class="card-body">
						
						<div id="reportsChart" style="display:block;"></div>
						<div id="sand_chart" style="display:none;" ></div>	
						</div>
					</div>
				</div>
		
				<div class="col-md-6">
					<div class="card">
						<div class="card-header">
							<h4>Search Graph</h4>
						</div>
						<div class="card-body">
							<div id="searchChart"></div>
							
						</div>
					</div>
				</div>
				
				

				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h4>Overall Equipments Income</h4>
						</div>
						<div class="card-body"> 
						<div class="table-responsive"> 
						<table class="table table-striped" id="rent_table">
							<thead>
							  <tr>
								<th scope="col">Equipment</th>
								<th scope="col">Total</th>
								
							  </tr>
							</thead>
							<tbody>
							<?php

include "conn.php";


$sql = "SELECT equipment_name, SUM(total) AS total_sum FROM rental WHERE paid_status='Paid' GROUP BY equipment_name";
$result = $conn->query($sql);
$i=1;
if ($result->num_rows > 0) {
while ($row = $result->fetch_assoc()) {
?>

							  <tr>
								<th scope="row"> <?php echo $row['equipment_name'];?>	</th>
								<td> <?php echo $row['total_sum'];?> </td>
								

							  </tr>

							  <?php
    }
} else {
?>
        <tr>
            <td colspan="4">No data found</td>
        </tr>
<?php
}

?>  
							</tbody>
						  </table>
						  </div>
						</div>
					</div>
				</div>

		   </div>
		</div>
	</div>


	<!-- Footer -->				
	<footer>
		<div class="footer">
			<div class="float-start">
				<p>2024 &copy; Rental</p>
			</div>
				<div class="float-end">
					<p>Crafted with 
						<span class="text-danger">
							<i class="fa fa-heart"></i> by 
							<a href="https://www.facebook.com/mindorostateuccs" class="author-footer">BSIT</a>
						</span> 
					</p>
			</div>
		</div>
	</footer>


	<!-- Preloader -->
	<div class="loader">
		<div class="spinner-border text-light" role="status">
			<span class="sr-only">Loading...</span>
		</div>
	</div>
	
	<!-- Loader -->
	<div class="loader-overlay"></div>

	<!-- General JS Scripts -->
	<script src="assets/js/atrana.js"></script>

	<!-- JS Libraies -->
	<script src="assets/modules/jquery/jquery.min.js"></script>
	<script src="assets/modules/bootstrap-5.1.3/js/bootstrap.bundle.min.js"></script>
	<script src="assets/modules/popper/popper.min.js"></script>

	<!-- Chart Js -->
	<script src="assets/modules/apexcharts/apexcharts.js"></script>
	<script src="assets/js/ui-apexcharts.js"></script>

    <!-- Template JS File -->
	<script src="assets/js/script.js"></script>
	<script src="assets/js/custom.js"></script>




<script src="monthly_chart_sales.js"></script>

<script src="rent_cards.js"></script>
<script src="orders_card.js"></script>





<script>
   const today = document.getElementById('today');
  const monthly = document.getElementById('monthly');
  const yearly = document.getElementById('yearly');
  const overall = document.getElementById('overall');
  // Add event listener to toggle between Today and Monthly
  today.addEventListener('click', () => {
    document.getElementById('today_revenue').style.display = 'block';
    document.getElementById('monthly_revenue').style.display = 'none';
	document.getElementById('yearly_revenue').style.display = 'none';
	document.getElementById('overall_revenue').style.display = 'none';

	document.getElementById('today_orders_revenue').style.display = 'block';
	document.getElementById('monthly_orders_revenue').style.display = 'none';
	document.getElementById('yearly_orders_revenue').style.display = 'none';
	document.getElementById('overall_orders_revenue').style.display = 'none';

	document.getElementById('today_overall_sales').style.display = 'block';
	document.getElementById('monthly_overall_sales').style.display = 'none';
	document.getElementById('yearly_overall_sales').style.display = 'none';
	document.getElementById('overall_sales').style.display = 'none';
  });


  monthly.addEventListener('click', () => {
	document.getElementById('monthly_revenue').style.display = 'block';
    document.getElementById('today_revenue').style.display = 'none';
	document.getElementById('yearly_revenue').style.display = 'none';
	document.getElementById('overall_revenue').style.display = 'none';

	document.getElementById('monthly_orders_revenue').style.display = 'block';
	document.getElementById('today_orders_revenue').style.display = 'none';
	document.getElementById('yearly_orders_revenue').style.display = 'none';
	document.getElementById('overall_orders_revenue').style.display = 'none';

	document.getElementById('monthly_overall_sales').style.display = 'block';
	document.getElementById('today_overall_sales').style.display = 'none';
	document.getElementById('yearly_overall_sales').style.display = 'none';
	document.getElementById('overall_sales').style.display = 'none';
  });

  yearly.addEventListener('click', () => {
	document.getElementById('yearly_revenue').style.display = 'block';
	document.getElementById('monthly_revenue').style.display = 'none';
    document.getElementById('today_revenue').style.display = 'none';
	document.getElementById('overall_revenue').style.display = 'none';

	document.getElementById('yearly_orders_revenue').style.display = 'block';
	document.getElementById('monthly_orders_revenue').style.display = 'none';
	document.getElementById('today_orders_revenue').style.display = 'none';
	document.getElementById('overall_orders_revenue').style.display = 'none';

	document.getElementById('yearly_overall_sales').style.display = 'block';
	document.getElementById('monthly_overall_sales').style.display = 'none';
	document.getElementById('today_overall_sales').style.display = 'none';
	document.getElementById('overall_sales').style.display = 'none';
  });

  overall.addEventListener('click', () => {
	document.getElementById('yearly_revenue').style.display = 'none';
	document.getElementById('monthly_revenue').style.display = 'none';
    document.getElementById('today_revenue').style.display = 'none';
	document.getElementById('overall_revenue').style.display = 'block';

	document.getElementById('overall_orders_revenue').style.display = 'block';
	document.getElementById('yearly_orders_revenue').style.display = 'none';
	document.getElementById('monthly_orders_revenue').style.display = 'none';
	document.getElementById('today_orders_revenue').style.display = 'none';

	document.getElementById('overall_sales').style.display = 'block';
	document.getElementById('yearly_overall_sales').style.display = 'none';
	document.getElementById('monthly_overall_sales').style.display = 'none';
	document.getElementById('today_overall_sales').style.display = 'none';
	
  });



</script>






<script>
   const today = document.getElementById('today');
  const monthly = document.getElementById('monthly');
  const yearly = document.getElementById('yearly');
  const overall = document.getElementById('overall');
  // Add event listener to toggle between Today and Monthly
  today.addEventListener('click', () => {
    document.getElementById('today_revenue').style.display = 'block';
    document.getElementById('monthly_revenue').style.display = 'none';
  });




  monthly.addEventListener('click', () => {
    document.getElementById('today_revenue').style.display = 'none';
    document.getElementById('monthly_revenue').style.display = 'block';
  });



</script>




<script>
	 const toggleMonthlySales = document.getElementById('toggle-sales-monthly');

// Get the elements to toggle
const heMonthlySales = document.getElementById('he_monthly_sales');
const sandMonthlySales = document.getElementById('sand_monthly_sales');
const reportsChart = document.getElementById('reportsChart');
const sand_chart = document.getElementById('sand_chart');
// Add event listener to toggle the sections
toggleMonthlySales.addEventListener('change', () => {
  if (toggleMonthlySales.checked) {
	reportsChart.style.display = 'none';
	heMonthlySales.style.display = 'none';
	sand_chart.style.display = 'block';
	sandMonthlySales.style.display = 'block';
  } else {
	reportsChart.style.display = 'block';
	heMonthlySales.style.display = 'block';
	sandMonthlySales.style.display = 'none';
	sand_chart.style.display = 'none';
  }
});
</script>



<script>
	 $(document).ready(function() {
        $(".generate_btn").click(function(e) {
            e.preventDefault(); 

  
            $("#reportModal").modal("show");
        });
    });


	 document.getElementById("close_modal_btn").addEventListener("click", function() {
        $('#reportModal').modal('hide'); // Manually hide the modal
    });


	
</script>
<script>
 
    </script>
</script>

<script>
	 flatpickr("#start_date_calendar", {
            dateFormat: "F d, Y", // Set date format to "May 03, 2024"
            onClose: function(selectedDates, dateStr, instance) {
                // Convert the selected date format and set it to the converted input
                document.getElementById("start_date").value = convertDateFormat(dateStr);
            }
        });

        // Function to convert date format
        function convertDateFormat(inputDate) {
            // Create a date object from the input string
            var dateObj = new Date(inputDate);

            // Check if the date object is valid
            if (isNaN(dateObj.getTime())) {
                return "Invalid Date";
            }

           
            var year = dateObj.getFullYear();
            var month = String(dateObj.getMonth() + 1).padStart(2, '0');
            var day = String(dateObj.getDate()).padStart(2, '0');

            return `${year}-${month}-${day}`;
        }

        flatpickr("#end_date_calendar", {
            dateFormat: "F d, Y", // Set date format to "May 03, 2024"
            onClose: function(selectedDates, dateStr, instance) {
                // Convert the selected date format and set it to the converted input
                document.getElementById("end_date").value = convertDateFormat(dateStr);
            }
        });

        
        function convertDateFormat(inputDate) {
            
            var dateObj = new Date(inputDate);

            
            if (isNaN(dateObj.getTime())) {
                return "Invalid Date";
            }

            // Format the date as YYYY-MM-DD
            var year = dateObj.getFullYear();
            var month = String(dateObj.getMonth() + 1).padStart(2, '0');
            var day = String(dateObj.getDate()).padStart(2, '0');

            return `${year}-${month}-${day}`;
        }
</script>




<script src="generate_report.js">

</script>


<script>
document.addEventListener("DOMContentLoaded", () => {
let chart;
let existingData = []; // Store existing data to check for updates

// Function to create or update the chart
function createOrUpdateChart(data) {
if (!chart) {
// Create the initial chart
chart = new ApexCharts(document.querySelector("#sand_chart"), {
series: data,
chart: {
    height: 350,
    type: 'area',
    toolbar: {
        show: true,
        tools: {
            download: true,
            selection: true,
            zoom: true,
            zoomin: true,
            zoomout: true,
            pan: true,
            reset: true | '<img src="/static/icons/reset.png" width="20">',
            customIcons: []
        },
        autoSelected: 'zoom'
    },
},
markers: {
    size: 5
},
colors: ['#4154f1', '#2eca6a', '#ff771d', '#ffdc34', '#a35cff', '#ff5722', '#00bcd4', '#e91e63', '#8bc34a', '#ffc107', '#9c27b0', '#2196f3'],
fill: {
    type: "gradient",
    gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.4,
        opacityTo: 0.5,
        stops: [0, 90, 100]
    }
},
dataLabels: {
    enabled: false
},
stroke: {
    curve: 'smooth',
    width: 2
},
tooltip: {
      x: {
          formatter: function(val) {
              return val;
          }
      },
      y: {
          formatter: function(val) {
              return `₱ ${Math.floor(val).toLocaleString()}`; // Format to remove decimals and add comma separator
          }
      },
      shared: true, // Enable shared tooltip for all series
      custom: function({ series, seriesIndex, dataPointIndex, w }) {
          const seriesData = w.globals.series;
          const tooltipData = [];
          let hasData = false;

          seriesData.forEach((dataSet, index) => {
              const value = dataSet[dataPointIndex];
              if (value !== null && value !== undefined && value !== 0) {
                  const formattedValue = `₱ ${Math.floor(value).toLocaleString()}`;
                  tooltipData.push(`<span style="margin-top:10px; display: inline-block; width: 10px; height: 10px; background-color: ${w.config.colors[index]}; border-radius: 50%; margin-right: 5px;"></span><span style="font-size:12.5px; ">${w.config.series[index].name}:</span><span style="font-weight: 600; margin-left:8px;">${formattedValue}</span><br/>`);

                  hasData = true;
              }
          });

          if (hasData) {
              tooltipData.unshift('<div style="box-shadow: 10px 16px 40px 11px rgba(0,0,0,0.6); -webkit-box-shadow: 15px 19px 37px 4px rgba(0,0,0,0.6); -moz-box-shadow: 15px 19px 37px 4px rgba(0,0,0,0.6); background-color: rgba(0, 0, 0, 0); color: #fff; border-radius: 5px; padding: 8px;">');
              tooltipData.push('</div>');
          }

          return tooltipData.join('');
      }
  }

});

// Render the chart
chart.render();
} else {
// Update the existing chart with new data
chart.updateSeries(data);
}
}


// Function to fetch data from PHP file and update chart
function fetchDataAndUpdateChart() {
const xhr = new XMLHttpRequest();
xhr.open('GET', 'fetch_orders_data.php', true);
xhr.onload = function() {
if (xhr.status >= 200 && xhr.status < 300) {
    const data = JSON.parse(xhr.responseText);

    const filteredData = data.filter(month => month.data.length > 0);

    const newData = filteredData.map(month => ({
        name: month.name,
        data: month.data
    }));

    // Check if there are updates in the new data
    const updatedData = newData.filter(item => {
        const existingItem = existingData.find(existing => existing.name === item.name);
        return existingItem ? JSON.stringify(existingItem.data) !== JSON.stringify(item.data) : true;
    });

    if (updatedData.length > 0) {
        updatedData.forEach(item => {
            const existingItemIndex = existingData.findIndex(existing => existing.name === item.name);
            if (existingItemIndex !== -1) {
                // Update the existing data with the new data
                existingData[existingItemIndex].data = item.data;
            } else {
                existingData.push(item);
            }
        });

        // Update the chart with the updated data
        createOrUpdateChart(existingData.map(item => ({ name: item.name, data: item.data })));

        // Calculate and download the CSV with total revenue
        // generateAndDownloadCSV(existingData); // Remove this line
    }
} else {
    console.error('Failed to fetch data');
}
};
xhr.send();
}

// Call fetchDataAndUpdateChart initially
fetchDataAndUpdateChart();

// Set interval to fetch data every 5 seconds (adjust as needed)
setInterval(fetchDataAndUpdateChart, 1000); // Fetch data every 5 seconds

// Event listener for Download CSV button
document.querySelector('#downloadRestaurantCSVButton').addEventListener('click', () => {
generateAndDownloadRestaurantCSV(existingData);
});

document.querySelector('#downloadRestaurantPNGButton').addEventListener('click', () => {
downloadPNGRestaurantChart();
});

// Function to generate and download CSV with total revenue
function generateAndDownloadRestaurantCSV(data) {
let csvContent = 'Revenue';
data.forEach(item => {
csvContent += `,${item.name}`;
});
csvContent += '\n';

const maxRows = Math.max(...data.map(item => item.data.length));

for (let i = 0; i < maxRows; i++) {
let row = '';
data.forEach(item => {
    const value = item.data[i] || '';
    row += `,${value}`;
});
csvContent += `${row}\n`;
}

csvContent += '\nTotal ';
data.forEach(item => {
const total = item.data.reduce((acc, val) => acc + parseFloat(val), 0);
csvContent += `,${total}`;
});
csvContent += '\n';


const overallTotal = data.reduce((acc, item) => {
const total = item.data.reduce((sum, val) => sum + parseFloat(val), 0);
return acc + total;
}, 0);
csvContent += `\nOverall,${overallTotal}\n`;


const blob = new Blob([csvContent], { type: 'text/csv' });
const url = window.URL.createObjectURL(blob);

const link = document.createElement('a');
link.href = url;
link.setAttribute('download', 'Restaurant_Revenue_Reports.csv');

// Append the link to the body and click it to trigger download
document.body.appendChild(link);
link.click();

// Cleanup
document.body.removeChild(link);
window.URL.revokeObjectURL(url);
}


function downloadPNGRestaurantChart() {
const chartCanvas = document.querySelector('#RestaurantreportsChart svg'); // Assuming the chart is an SVG element
const chartSVG = new XMLSerializer().serializeToString(chartCanvas);
const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d');
const img = new Image();

img.onload = function() {
canvas.width = img.width;
canvas.height = img.height + 50; // Increased height to accommodate total revenue text
ctx.fillStyle = '#ffffff'; // White color
ctx.fillRect(0, 0, canvas.width, canvas.height);
ctx.drawImage(img, 0, 0);

// Calculate and draw totals for each month
const data = existingData.map(item => item.data);
const totals = data.map(monthData => monthData.reduce((acc, val) => acc + parseFloat(val), 0));
const months = existingData.map(item => item.name);
ctx.fillStyle = '#000000'; // Black color for text
ctx.font = '14px Arial';

let totalText = 'Monthly Revenue:';
months.forEach((month, index) => {
    totalText += ` ${month}: ₱${totals[index].toLocaleString()} `;
});

// Draw total revenue text at the bottom
ctx.fillText(totalText, 10, canvas.height - 10); // Adjust position as needed

// Create download link and trigger download
const link = document.createElement('a');
link.href = canvas.toDataURL('image/png');
link.download = 'Restaurant_Chart_Report.png';
document.body.appendChild(link);
link.click();
document.body.removeChild(link);
};

img.src = 'data:image/svg+xml;base64,' + btoa(chartSVG);
}
});



</script>



<script>
$(document).ready(function(){
    $.ajax({
        url: 'get_search_data.php',
        type: 'GET',
        dataType: 'json',
        success: function(data) {
            var options = {
                series: [{
                    data: Object.values(data)
                }],
                chart: {
                    type: 'bar',
                    height: 345
                },
                plotOptions: {
                    bar: {
                        vertical: true,
						
                    }
                },
                xaxis: {
                    categories: Object.keys(data),
                    labels: {
                        formatter: function(val, index) {
                            return val + " (" + data[val].toFixed(0) + "%)"; // Displaying the category along with its percentage value
                        }
                    }
                },
                yaxis: {
                    min: 0,
                    max: 100,
                    labels: {
                        formatter: function(val) {
                            return val.toFixed(0) + "%";
                        }
                    }
                },
                tooltip: {
                    y: {
                        formatter: function(val) {
                            return val.toFixed(2) + "%";
                        }
                    }
                }
            };

            var chart = new ApexCharts(document.querySelector("#searchChart"), options);
            chart.render();
        }
    });
});





</script>
<!-- Template JS File -->
<script src="assets/js/script.js"></script>
<script src="assets/js/custom.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Include the Canvas library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>

 </body>
</html>
