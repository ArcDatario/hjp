             
        <div class="form-group" id="bansud_barangay" style="display:none;">
                <label for="municipality" class="col-form-label">Barangay</label>
                
            <select class="form-control" id="barangay" name="barangay" style="background: transparent; border: none; border-bottom: 1px solid #3B3E4B; border-radius: 1px !important; text-align: center; font-size: 1rem;">
                <option disabled selected hidden>Choose..</option>
                
                <div class="bansud" id="bansud">
                <option value="Alcadesma" style="background:white;">Alcadesma</option>
                <option value="Bato" style="background:white;">Bato</option>
                <option value="Conrazon" style="background:white;">Conrazon</option>
                <option value="Malo" style="background:white;">Malo</option>
                <option value="Manihala" style="background:white;">Manihala</option>
                <option value="Pag-asa" style="background:white;">Pag-asa</option>
                <option value="Poblacion" style="background:white;">Poblacion</option>
                <option value="Proper Bansud" style="background:white;">Proper Bansud</option>
                <option value="Proper Tiguisan" style="background:white;">Proper Tiguisan</option>
                <option value="Rosacara" style="background:white;">Rosacara</option>
                <option value="Salcedo" style="background:white;">Salcedo</option>
                <option value="Sumagui" style="background:white;">Sumagui</option>
                <option value="Villa Pag-asa" style="background:white;">Villa Pag-asa</option>
                </div>

                <div class="gloria" id="gloria">
                <option value="Agos" style="background:white;">Agos</option>
<option value="Agsalin" style="background:white;">Agsalin</option>
<option value="Alma Villa" style="background:white;">Alma Villa</option>
<option value="Andres Bonifacio" style="background:white;">Andres Bonifacio</option>
<option value="Balete" style="background:white;">Balete</option>
<option value="Banus" style="background:white;">Banus</option>
<option value="Banutan" style="background:white;">Banutan</option>
<option value="Bulaklakan" style="background:white;">Bulaklakan</option>
<option value="Buong Lupa" style="background:white;">Buong Lupa</option>
<option value="Gaudencio Antonino" style="background:white;">Gaudencio Antonino</option>
<option value="Guimbonan" style="background:white;">Guimbonan</option>
<option value="Kawit" style="background:white;">Kawit</option>
<option value="Lucio Laurel" style="background:white;">Lucio Laurel</option>
<option value="Macario Adriatico" style="background:white;">Macario Adriatico</option>
<option value="Malamig" style="background:white;">Malamig</option>
<option value="Malayong" style="background:white;">Malayong</option>
<option value="Maligaya" style="background:white;">Maligaya</option>
<option value="Malubay" style="background:white;">Malubay</option>
<option value="Manguyang" style="background:white;">Manguyang</option>
<option value="Maragooc" style="background:white;">Maragooc</option>
<option value="Mirayan" style="background:white;">Mirayan</option>
<option value="Narra" style="background:white;">Narra</option>
<option value="Papandungin" style="background:white;">Papandungin</option>
<option value="San Antonio" style="background:white;">San Antonio</option>
<option value="Santa Maria" style="background:white;">Santa Maria</option>
<option value="Santa Theresa" style="background:white;">Santa Theresa</option>
<option value="Tambong" style="background:white;">Tambong</option>
                </div>

                <div class="pinamalayan" id="pinamalayan">
                <option value="Anoling" style="background:white;">Anoling</option>
<option value="Bacungan" style="background:white;">Bacungan</option>
<option value="Bangbang" style="background:white;">Bangbang</option>
<option value="Banilad" style="background:white;">Banilad</option>
<option value="Buli" style="background:white;">Buli</option>
<option value="Cacawan" style="background:white;">Cacawan</option>
<option value="Calingag" style="background:white;">Calingag</option>
<option value="Del Razon" style="background:white;">Del Razon</option>
<option value="Guinhawa" style="background:white;">Guinhawa</option>
<option value="Inclanay" style="background:white;">Inclanay</option>
<option value="Lumangbayan" style="background:white;">Lumangbayan</option>
<option value="Malaya" style="background:white;">Malaya</option>
<option value="Maliangcog" style="background:white;">Maliangcog</option>
<option value="Maningcol" style="background:white;">Maningcol</option>
<option value="Marayos" style="background:white;">Marayos</option>
<option value="Marfrancisco" style="background:white;">Marfrancisco</option>
<option value="Nabuslot" style="background:white;">Nabuslot</option>
<option value="Pagalagala" style="background:white;">Pagalagala</option>
<option value="Palayan" style="background:white;">Palayan</option>
<option value="Pambisan Malaki" style="background:white;">Pambisan Malaki</option>
<option value="Pambisan Munti" style="background:white;">Pambisan Munti</option>
<option value="Panggulayan" style="background:white;">Panggulayan</option>
<option value="Papandayan" style="background:white;">Papandayan</option>
<option value="Pili" style="background:white;">Pili</option>
<option value="Quinabigan" style="background:white;">Quinabigan</option>
<option value="Ranzo" style="background:white;">Ranzo</option>
<option value="Rosario" style="background:white;">Rosario</option>
<option value="Sabang" style="background:white;">Sabang</option>
<option value="Santa Isabel" style="background:white;">Santa Isabel</option>
<option value="Santa Maria" style="background:white;">Santa Maria</option>
<option value="Santa Rita" style="background:white;">Santa Rita</option>
<option value="Santo Niño" style="background:white;">Santo Niño</option>
<option value="Wawa" style="background:white;">Wawa</option>
<option value="Zone I" style="background:white;">Zone I</option>
<option value="Zone II" style="background:white;">Zone II</option>
<option value="Zone III" style="background:white;">Zone III</option>
<option value="Zone IV" style="background:white;">Zone IV</option>
                </div>


            </select>
        </div>



    

            