<?php 

include "user_session.php";

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Rental Heavy Equipments</title>

    <!-- 
    - favicon
  -->
    <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml" />

    <!-- 
    - custom css link
  -->
    <link rel="stylesheet" href="./assets/css/styles.css" />

    <!-- 
    - google font link
  -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600&family=Open+Sans&display=swap"
      rel="stylesheet"
    />

 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        option{
         background: hsl(216, 38%, 95%);
         color: hsl(240, 22%, 25%);
    outline: 2px solid transparent;
    outline-offset: 5px;
    border-radius: 4px;
    transition: var(--transition);
    font-size:0.95rem;
    font-family:'Open Sans', sans-serif;
        }
        option::placeholder { color: hsl(219, 21%, 39%); }

        select{
         background: hsl(216, 38%, 95%);
         color: hsl(240, 22%, 25%);
      outline: 2px solid transparent;
       outline-offset: 5px;
       border-radius: 4px;
       transition: var(--transition);
         font-size:0.95rem;
         font-family:'Open Sans', sans-serif;
        }


        .swal2-input{
          width:80%;
        }

        .custom-modal-body{
         width:450px;
         background-color: white;
         box-shadow: 0 0 0 1000px rgba(0, 0, 0, 0.5);
         border-radius:15px;
        
        }
        .custom-modal-body:hover{
         

        }
        .custom-confirm-button{
          background-color:#E88A1A;
        }
       
      </style>
  </head>

  <body>
    <!-- 
    - #HEADER
  -->
  <?php
  // Check if the booking was successful
  if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true) {
      // Display Swal2 toast for successful booking
      echo '<script>
              const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 6000,
                timerProgressBar: true,
                didOpen: (toast) => {
                  toast.onmouseenter = Swal.stopTimer;
                  toast.onmouseleave = Swal.resumeTimer;
                }
              });
              Toast.fire({
                icon: "success",
                title: "Signed In Successful!"
              });
            </script>';
      // Unset the session variable to prevent displaying the toast on page refresh
      unset($_SESSION['logged_in']);
  }

  ?>
  
    <header class="d_header" data-header style="z-index:1000;">
      <div class="d_container">
        <div class="overlay" data-overlay></div>

        <a href="#" class="logo">
          <img
            src="./assets/images/newlogo.png"
            alt="Rental logo"
            height="120"
            width="120"
          />
        </a>

        <nav class="navbar" data-navbar>
          <ul class="navbar-list">
            <li>
              <a href="#home" class="navbar-link" data-nav-link>Home</a>
            </li>

            <li>
              <a href="#featured-car" class="navbar-link" data-nav-link
                >Equipments</a
              >
            </li>

            <li>
              <a href="#blog" class="navbar-link" data-nav-link>Most Rented</a>
            </li>
          
            <li>
              <a href="#get-started" class="navbar-link" data-nav-link>Get Started</a>
            </li>

              
            
          </ul>
        </nav>

        <div class="d_header-actions">
          <div class="d_header-contact">
            <a href="tel:88002345678" class="contact-link">63 956 632 0135</a>

            <span class="contact-time">Mon - Sat: 9:00 am - 6:00 pm</span>
          </div>

          <a href="#featured-car" class="btn" aria-labelledby="aria-label-txt" z-index:1;>
            <ion-icon name="car-outline"></ion-icon>
            <span id="aria-label-txt">Explore</span>
          </a>
          
          <a href="#" user-id="<?php echo $_SESSION['user_id'];?>" class=" user-btn" aria-label="Profile" >
            <img src="../user_images/<?php echo htmlspecialchars($_SESSION['image']); ?>" alt="" style="border-radius:20% !important;" height="33" width="33" title="Account">
          </a>
          

          <button
            class="nav-toggle-btn"
            data-nav-toggle-btn
            aria-label="Toggle Menu"
          >
            <span class="one"></span>
            <span class="two"></span>
            <span class="three"></span>
          </button>
        </div>
      </div>
    </header>

    <main>
      <article>
        <!-- 
        - #HERO
      -->

        <section class="section hero" id="home">
          <div class="container">
            <div class="hero-content">
              <h2 class="h1 hero-title">Build Faster With Our Equipments</h2>

              <p class="hero-text">
                We offer Rental Heavy Equipments for your Needs!
              </p>
            </div>

            <div class="hero-banner"></div>

            <form action="" class="hero-form">
              <div class="input-wrapper">
                <label for="input-1" class="input-label"
                  >Equipment Category</label
                >

                <select  name="category"
                  id="input-1"
                  class="input-field" style="width:100%; background:transparent; border:none;">
                        <option disabled selected hidden>Category</option>
                        <option  value="Loaders">Loaders</option>
                        <option value="Backhoes">Backhoes</option>
                        <option value="Bulldozers">Bulldozers</option>
                        <option value="Excavators">Excavators</option>
                        <option value="Trenchers">Trenchers</option>
                        <option value="Compactors">Compactors</option>
                        <option value="Mixers">Mixers</option>
                        <option value="Dump Trucks">Dump Trucks</option>
                        <option value="Forwarder">Forwarder</option>
                    </select>
              </div>

              <div class="input-wrapper">
                <label for="input-2" class="input-label"
                  >Daily Rate (₱)</label
                >

                <input
                  type="text"
                  name="monthly-pay"
                  id="input-2"
                  class="input-field"
                  placeholder=" Enter your budget "
                />
              </div>

              

              <button type="submit" class="btn">Search</button>

              
            </form>
          </div>
        </section>

        <!-- 
        - #FEATURED CAR
      -->

        <section class="section featured-car" id="featured-car">
          <div class="container">
            <div class="title-wrapper">
              <h2 class="h2 section-title">Equipments</h2>

              <a href="all_equipments.php" class="featured-car-link">
                <span>View All</span>

                <ion-icon name="arrow-forward-outline"></ion-icon>
              </a>
            </div>

            <ul class="featured-car-list">

            <?php

include "conn.php";


$sql = "SELECT * FROM equipment_tbl order by id desc";
$result = $conn->query($sql);
$i=1;
if ($result->num_rows > 0) {
while ($row = $result->fetch_assoc()) {
?>            
              <li>
                <div class="featured-car-card">
                  <figure class="card-banner">
                    <img
                      src="../admin/functions/equipment_images/<?php echo $row['image']; ?>"
                      alt="Toyota RAV4 2021"
                      loading="lazy"
                      width="440"
                      height="300"
                      class="w-100"
                    />
                  </figure>

                  <div class="card-content">
                    <div class="card-title-wrapper">
                      <h3 class="h3 card-title">
                        <a href="#"><?php echo $row['equipment']; ?></a>
                      </h3>

                      <data class="year" value="2021"><?php echo $row['year_model']; ?></data>
                    </div>

                      <ul class="card-list">
                      <li class="card-list-item">
                        <ion-icon name="people-outline"></ion-icon>
                        <span class="card-item-text"><?php echo $row['capacity']; ?></span>
                      </li>

                      <li class="card-list-item">
                        <ion-icon name="flash-outline"></ion-icon>
                        <span class="card-item-text"><?php echo $row['fuel']; ?></span>
                      </li>

                      <li class="card-list-item">
                        <ion-icon name="speedometer-outline"></ion-icon>

                        <span class="card-item-text"><?php echo $row['kmperliter']; ?>km / 1-litre</span>
                      </li>

                      <li class="card-list-item">
                        <ion-icon name="hardware-chip-outline"></ion-icon>

                        <span class="card-item-text"><?php echo $row['type']; ?></span>
                      </li>
                    </ul>

                    <div class="card-price-wrapper">
                      <p class="card-price"><strong>₱<?php echo $row['rate_per_day']; ?></strong> / day</p>

                      <button class="btn rent_now_btn"
                      id="rent_now_btn"
                      data-toggle="modal" data-target="#exampleModal"
                      data-user-id="<?php echo $_SESSION['user_id'];?>"
          data-id="<?php echo $row['id']; ?>"
          user_email="<?php echo htmlspecialchars($_SESSION['email']); ?>"
          equipment-id="<?php echo $row['id']; ?>"
         data-equipment-name="<?php echo $row['equipment']; ?>"
         data-rate-per-day="<?php echo $row['rate_per_day']; ?>"
         data-equipment-image="<?php echo $row['image']; ?>"
         data-year-model ="<?php echo $row['year_model']; ?>"
         data-capacity="<?php echo $row['capacity']; ?>"  
         data-fuel="<?php echo $row['fuel']; ?>"     
         data-kmperliter="<?php echo $row['kmperliter']; ?>" 
         data-type="<?php echo $row['type']; ?>"
         onclick="updateModalContent(this)"
         
        
         "
                      > Rent now</button>

                    </div>
                  </div>
                </div>
              </li>
              
              <?php
    }
} else {
?>
        <tr>
            <td colspan="4">No data found</td>
        </tr>
<?php
}

?>  
<a href="all_equipments.php" class="featured-car-link">
                <span>View All</span>

                <ion-icon name="arrow-forward-outline"></ion-icon>
              </a>
            </ul>
          </div>
        </section>



<?php include "rent_modal.php";?>






        <!-- 
        - #GET START
      -->

        <section class="section get-start" id="get-started">
          <div class="container">
            <h2 class="h2 section-title">Get started with 4 simple steps</h2>

            <ul class="get-start-list">
              <li>
                <div class="get-start-card">
                  <div class="card-icon icon-1">
                    <ion-icon name="person-add-outline"></ion-icon>
                  </div>

                  <h3 class="card-title" style="font-size:1.3rem;">Create a profile</h3>

                  <p class="card-text">
                  Begin your journey: 
                  Click 'Get Started' to start  your account setup process. 
                  <a href="#" class="card-link" >Get started</a>
                  </p>

                  
                </div>
              </li>

              <li>

                <div class="get-start-card">
                  <div class="card-icon icon-2">

                  <ion-icon name="calendar-number-outline"></ion-icon>
                  </div>

                  <h3 class="card-title" style="font-size:1.3rem;">Select an Equipment/s</h3>
  
                  <p class="card-text">
                    Just simply click on "Rent now"and select the date duration for your selected equipment/s.
                  </p>
                </div>
              </li>

              <li>
                <div class="get-start-card">
                  <div class="card-icon icon-3">
                  <ion-icon name="location-outline"></ion-icon>
                  </div>

                  <h3 class="card-title" style="font-size:1.3rem;">Go to our Location</h3>

                  <p class="card-text">
                    It to make a type specimen book. It has survived not only
                    five centuries, but also the leap into electronic
                  </p>
                </div>
              </li>

              <li>
                <div class="get-start-card">
                  <div class="card-icon icon-4">
                    <ion-icon name="card-outline"></ion-icon>
                  </div>

                  <h3 class="card-title" style="font-size:1.3rem;">Make a deal</h3>

                  <p class="card-text">
                    There are many variations of passages of  available,
                    but the majority have suffered alteration
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </section>

        <!-- 
        - #BLOG
      -->

        <section class="section blog" id="blog">
          <div class="container">
            <h2 class="h2 section-title">Most Rented</h2>

            <ul class="blog-list has-scrollbar">
              <li>
                <div class="blog-card">
                  <figure class="card-banner">
                    <a href="#">
                      <img
                        src="./assets/images/backhoe.jpg"
                        alt="Opening of new offices of the company"
                        loading="lazy"
                        class="w-100"
                      />
                    </a>

                    <a href="#" class="btn card-badge">Rent Now</a>
                  </figure>

                  <div class="card-content">
                    <h3 class="h3 card-title">
                      <a href="#">Caterpillar Heavy Duty</a>
                    </h3>

                    <div class="card-meta">
                      <div class="publish-date">
                        <ion-icon name="time-outline"></ion-icon>

                        <time datetime="2022-01-14">January 14, 2022</time>
                      </div>

                      <div class="comments">
                        <ion-icon name="chatbubble-ellipses-outline"></ion-icon>

                        <data value="114">114</data>
                      </div>
                    </div>
                  </div>
                </div>
              </li>

              <li>
                <div class="blog-card">
                  <figure class="card-banner">
                    <a href="#">
                      <img
                        src="./assets/images/truck.jpg"
                        alt="What cars are most vulnerable"
                        loading="lazy"
                        class="w-100"
                      />
                    </a>

                    <a href="#" class="btn card-badge">Rent Now</a>
                  </figure>

                  <div class="card-content">
                    <h3 class="h3 card-title">
                      <a href="#">Caterpillar Heavy Duty</a>
                    </h3>

                    <div class="card-meta">
                      <div class="publish-date">
                        <ion-icon name="time-outline"></ion-icon>

                        <time datetime="2022-01-14">January 14, 2022</time>
                      </div>

                      <div class="comments">
                        <ion-icon name="chatbubble-ellipses-outline"></ion-icon>

                        <data value="114">114</data>
                      </div>
                    </div>
                  </div>
                </div>
              </li>

              <li>
                <div class="blog-card">
                  <figure class="card-banner">
                    <a href="#">
                      <img
                        src="./assets/images/loader.jpg"
                        alt="Statistics showed which average age"
                        loading="lazy"
                        class="w-100"
                      />
                    </a>

                    <a href="#" class="btn card-badge">Rent Now</a>
                  </figure>

                  <div class="card-content">
                    <h3 class="h3 card-title">
                      <a href="#">Caterpillar Heavy Duty</a>
                    </h3>

                    <div class="card-meta">
                      <div class="publish-date">
                        <ion-icon name="time-outline"></ion-icon>

                        <time datetime="2022-01-14">January 14, 2022</time>
                      </div>

                      <div class="comments">
                        <ion-icon name="chatbubble-ellipses-outline"></ion-icon>

                        <data value="114">114</data>
                      </div>
                    </div>
                  </div>
                </div>
              </li>

              <li>
                <div class="blog-card">
                  <figure class="card-banner">
                    <a href="#">
                      <img
                        src="./assets/images/truck.jpg"
                        alt="What´s required when renting a car?"
                        loading="lazy"
                        class="w-100"
                      />
                    </a>

                    <a href="#" class="btn card-badge">Rent Now</a>
                  </figure>

                  <div class="card-content">
                    <h3 class="h3 card-title">
                      <a href="#">Caterpillar Heavy Duty</a>
                    </h3>

                    <div class="card-meta">
                      <div class="publish-date">
                        <ion-icon name="time-outline"></ion-icon>

                        <time datetime="2022-01-14">January 14, 2022</time>
                      </div>

                      <div class="comments">
                        <ion-icon name="chatbubble-ellipses-outline"></ion-icon>

                        <data value="114">114</data>
                      </div>
                    </div>
                  </div>
                </div>
              </li>

              <li>
                <div class="blog-card">
                  <figure class="card-banner">
                    <a href="#">
                      <img
                        src="./assets/images/loader.jpg"
                        alt="New rules for handling our cars"
                        loading="lazy"
                        class="w-100"
                      />
                    </a>

                    <a href="#" class="btn card-badge">Rent Now</a>
                  </figure>

                  <div class="card-content">
                    <h3 class="h3 card-title">
                      <a href="#">Caterpillar Heavy Duty</a>
                    </h3>

                    <div class="card-meta">
                      <div class="publish-date">
                        <ion-icon name="time-outline"></ion-icon>

                        <time datetime="2022-01-14">January 14, 2022</time>
                      </div>

                      <div class="comments">
                        <ion-icon name="chatbubble-ellipses-outline"></ion-icon>

                        <data value="114">114</data>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
              <li>
                <div class="blog-card">
                  <figure class="card-banner">
                    <a href="#">
                      <img
                        src="./assets/images/backhoe.jpg"
                        alt="New rules for handling our cars"
                        loading="lazy"
                        class="w-100"
                      />
                    </a>

                    <a href="#" class="btn card-badge">Rent Now</a>
                  </figure>

                  <div class="card-content">
                    <h3 class="h3 card-title">
                      <a href="#">Caterpillar Heavy Duty</a>
                    </h3>

                    <div class="card-meta">
                      <div class="publish-date">
                        <ion-icon name="time-outline"></ion-icon>

                        <time datetime="2022-01-14">January 14, 2022</time>
                      </div>

                      <div class="comments">
                        <ion-icon name="chatbubble-ellipses-outline"></ion-icon>

                        <data value="114">114</data>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </section>
      </article>
    </main>

    <!-- 
    - #FOOTER
  -->

    <footer class="footer">
      <div class="container">
        <div class="footer-top">
          <div class="footer-brand">
            <a href="#" class="logo">
              <h2>Rental</h2>
            </a>

            <p class="footer-text">
            Unlocking Efficiency and Performance: Experience top-tier 
            heavy equipment rental services tailored to your project needs. 
            Trust in our expertise to deliver reliable machinery, 
            ensuring smooth operations and optimal productivity on every job site.
            </p>
          </div>

          <ul class="footer-list">
            <li>
              <p class="footer-list-title">Company</p>
            </li>

            <li>
              <a href="#" class="footer-link">About us</a>
            </li>

            <li>
              <a href="#" class="footer-link">Pricing plans</a>
            </li>

            <li>
              <a href="#" class="footer-link">Our blog</a>
            </li>

            <li>
              <a href="#" class="footer-link">Contacts</a>
            </li>
          </ul>

          <ul class="footer-list">
            <li>
              <p class="footer-list-title">Support</p>
            </li>

            <li>
              <a href="#" class="footer-link">Help center</a>
            </li>

            <li>
              <a href="#" class="footer-link">Ask a question</a>
            </li>

            <li>
              <a href="#" class="footer-link">Privacy policy</a>
            </li>

            <li>
              <a href="#" class="footer-link">Terms & conditions</a>
            </li>
          </ul>

          <ul class="footer-list">
            <li>
              <p class="footer-list-title">Our Location</p>
            </li>

            <li>
              <a href="#" class="footer-link">Gloria</a>
            </li>

            <li>
              <a href="#" class="footer-link">Bansud</a>
            </li>

            <li>
              <a href="#" class="footer-link">Pinamalayan</a>
            </li>

            <li>
              <a href="#" class="footer-link">Bongabong</a>
            </li>

          </ul>
        </div>

        <div class="footer-bottom">
          <ul class="social-list">
            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-instagram"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-linkedin"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-skype"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="mail-outline"></ion-icon>
              </a>
            </li>
          </ul>

          <p class="copyright">
            &copy; 2024 <a href="#">BSIT</a>. All Rights Reserved
          </p>
        </div>
      </div>
    </footer>

    <!-- 
    - custom js link
  -->
    <script src="./assets/js/script.js"></script>

    <!-- 
    - ionicon link
  -->
    <script
      type="module"
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"
    ></script>
    <script
      nomodule
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"
    ></script>

    <script>
      $(document).ready(function() {
    // Check if there's a success message in the URL (indicating successful registration)
    const urlParams = new URLSearchParams(window.location.search);
    const successMessage = urlParams.get('success');
    if (successMessage === 'true') {
        // Show SweetAlert2 toast with success message
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });
        Toast.fire({
            icon: 'success',
            title: 'Registration successful'
        });
    }
});

    </script>


<!-- JavaScript to handle button click event and trigger Swal modal -->

<script type="text/javascript">

function updateModalContent(button) {
    // Get the equipment name, equipment ID, and rate per day from the data attributes of the button
    var equipmentName = button.getAttribute('data-equipment-name');
    var equipmentID = button.getAttribute('equipment-id');
    var userID = button.getAttribute('data-user-id');
    var ratePerDay = button.getAttribute('data-rate-per-day');
    var equipmentImage = button.getAttribute('data-equipment-image');
    var yearModel = button.getAttribute('data-year-model');
    var userEmail = button.getAttribute('user_email');
    

    var equipmentInputID = document.getElementById('equipment_id').value;
    
    // Update the content of the modal's equipment elements with the retrieved values
    document.getElementById('equipment').innerText = equipmentName;
    document.getElementById('year_model').innerText = '- ' + yearModel;
    document.getElementById('user_email').value = userEmail;
    document.getElementById('equipment_id').value = equipmentID;
    document.getElementById('user_id').value = userID;
    document.getElementById('rate_per_day').value = ratePerDay;

    document.getElementById('rate_per_day_text').innerText = '₱'+ ratePerDay + ' /day' ;
    document.getElementById('equipment_image').src = '../admin/functions/equipment_images/' + equipmentImage;
    
    document.getElementById('range_date').value = '';
    document.getElementById('total').innerText = '';

    
    

}



function calculateTotal() {
    // Get the range of dates from the input field
    var dateRange = document.getElementById('range_date').value;

    // Split the range into start and end dates
    var dates = dateRange.split(" to ");
    var startDate = new Date(dates[0]);
    var endDate = new Date(dates[1]);

    // Check if both start and end dates are valid
    if (!isNaN(startDate) && !isNaN(endDate)) {
        // Calculate the duration in days (adding 1 to include both start and end dates)
        var duration = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1;

        // Get the rate per day
        var ratePerDay = parseFloat(document.getElementById('rate_per_day').value);

        // Calculate the total
        var total = ratePerDay * duration;

        // Update the content of the total <h1> element with the calculated total
        document.getElementById('total').innerText = 'Total: ₱' + total.toFixed(0);
        document.getElementById('total_input').value = total.toFixed(0);
        // Update the label text to show the duration
        document.getElementById('days_summary').innerText = 'Date Duration: ' + duration + ' days';
        document.getElementById('days_summary_text').value = duration + ' Days';
        // Convert and display the start and end dates in the desired format
        document.getElementById('convert_start_date').value = formatDate(startDate);
        document.getElementById('convert_end_date').value = formatDate(endDate);
    } else {
        // If either start or end date is invalid, reset the total and change the label text back to its original
        document.getElementById('total').innerText = '';
        document.getElementById('days_summary').innerText = 'Date Duration:';
        
        // Clear the converted date inputs
        document.getElementById('convert_start_date').value = '';
        document.getElementById('convert_end_date').value = '';
    }
}

// Function to format date as YYYY-MM-DD
function formatDate(date) {
    var year = date.getFullYear();
    var month = ('0' + (date.getMonth() + 1)).slice(-2);
    var day = ('0' + date.getDate()).slice(-2);
    return year + '-' + month + '-' + day;
}








</script>





<!-- Add this script at the end of your HTML document, after the modal code -->
<!-- Add this script at the end of your HTML document, after the modal code -->
<script>
  document.addEventListener('DOMContentLoaded', function () {
    // Find the "Rent" button
    var rentButton = document.getElementById('rent_btn');
    
    // Add event listener to the "Rent" button
    rentButton.addEventListener('click', function () {
        // Disable the "Rent" button to prevent multiple submissions
       
        
        // Check if the date input is empty
        var dateInput = document.getElementById('range_date').value;
        if (dateInput.trim() === '') {
            // If empty, display an error message
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "error",
                title: "Please select a date first"
            });
            // Re-enable the "Rent" button       
            return; // Stop further execution
        }
        
        // Gather form data
        var formData = new FormData(document.getElementById('rentalForm'));
        
        // Send form data to the server using AJAX
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'insert_rental.php', true);
        xhr.onload = function () {
            if (xhr.status === 200) {
                // Success message

                const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: "success",
                    title: "Rent Successfully"
                });
                // Close the modal
                $('#exampleModal').modal('hide');
            } else {
                // Error message
                alert('Error: ' + xhr.statusText);
                // Re-enable the "Rent" button
                rentButton.disabled = false;
            }
        };
        xhr.onerror = function () {
            // Error message
            alert('Request failed.');
            // Re-enable the "Rent" button
            rentButton.disabled = false;
        };
        xhr.send(formData);
    });
});

</script>





<script >
// Function to fetch rented dates for the equipment
function fetchRentedDates(equipmentId, callback) {
    $.ajax({
        url: 'fetch_rent_dates.php',
        method: 'POST',
        data: { equipment_id: equipmentId },
        success: function(response) {
            var rentedDates = JSON.parse(response);
            callback(rentedDates);
        },
        error: function(xhr, status, error) {
            console.error(xhr.responseText); // Log any errors to the console
        }
    });
}

// Function to disable past dates
function disablePastDates() {
    var today = new Date();
    today.setHours(0, 0, 0, 0);

    var disabledDates = [];
    var dateIterator = new Date(today);
    dateIterator.setDate(dateIterator.getDate() - 1);

    while (dateIterator > new Date(0)) {
        disabledDates.push(new Date(dateIterator));
        dateIterator.setDate(dateIterator.getDate() - 1);
    }

    return disabledDates;
}

// Set equipment ID when "Rent Now" button is clicked
$(".rent_now_btn").click(function() {
    var equipmentId = $(this).attr("equipment-id");
    $("#equipment_id_input").val(equipmentId);

    // Fetch rented dates for the equipment
    fetchRentedDates(equipmentId, function(rentedDates) {
        // Initialize Flatpickr for date range input with disabled dates
        flatpickr("#range_date", {
            mode: "range",
            altFormat: "F j, Y",
            altInput: false,
            dateFormat: "Y-m-d",
            disable: rentedDates.concat(disablePastDates()),
            onChange: function(selectedDates, dateStr, instance) {
                // Handle date change if needed
            }
        });
    });
});

// Initially disable past dates in the date range picker
flatpickr("#range_date", {
    mode: "range",
    altFormat: "F j, Y",
    altInput: false,
    dateFormat: "Y-m-d",
    disable: disablePastDates(),
    onChange: function(selectedDates, dateStr, instance) {
        // Handle date change if needed
    }
});



</script>



<script>
    window.__lc = window.__lc || {};
    window.__lc.license = 17827086;
    ;(function(n,t,c){function i(n){return e._h?e._h.apply(null,n):e._q.push(n)}var e={_q:[],_h:null,_v:"2.0",on:function(){i(["on",c.call(arguments)])},once:function(){i(["once",c.call(arguments)])},off:function(){i(["off",c.call(arguments)])},get:function(){if(!e._h)throw new Error("[LiveChatWidget] You can't use getters before load.");return i(["get",c.call(arguments)])},call:function(){i(["call",c.call(arguments)])},init:function(){var n=t.createElement("script");n.async=!0,n.type="text/javascript",n.src="https://cdn.livechatinc.com/tracking.js",t.head.appendChild(n)}};!n.__lc.asyncInit&&e.init(),n.LiveChatWidget=n.LiveChatWidget||e}(window,document,[].slice))
</script>
<noscript><a href="https://www.livechat.com/chat-with/17827086/" rel="nofollow">Chat with us</a>, powered by <a href="https://www.livechat.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a></noscript>



<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>


  </body>
</html>
