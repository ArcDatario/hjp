<div class="modal fade" id="perLoadModal">
    <div class="modal-dialog">
        <div class="modal-content" style="border-radius: 15px !important; margin-top: 15%;">
            <button type="button" class="close" style="margin-left: 90%;" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="modal-body">
                <img src="" id="perload_equipment_image" width="106%" height="300" style="margin-left: -3%; margin-top: -8%; border-radius: 15px; border: none;">
                <br>
                <h5 id="perload_equipment_name" style="float: left !important; margin-left: 3%;"></h5>
                <h5 id="perload_equipment_year_model" style="float: left !important; margin-left: 3%;"></h5>
                <h5 id="perload_rate_per_load_text" style="float: right; margin-right: 3%;"></h5>
                <br><br>
                <form method="post" id="perload_form">
                   
                                  
                    <input type="hidden" id="perload_equipment_id" name="perload_equipment_id" style="border:1px solid black;">
                    
                    <input type="hidden" id="perload_user_id" name="perload_user_id">
                    <input type="hidden" id="perload_equipment_rate_per_load" name="perload_equipment_rate_per_load">
                    <input type="hidden" id="perload_user_email" name="perload_user_email">
                    
                    <input type="hidden" id="perload_total_input" name="perload_total_input">

                    <input type="hidden" id="perload_load_summary_input" name="perload_total">
                    
                    <input type="hidden" id="equipment_load" name="per_load">
                    <input type="hidden" id="perload_equipment_name_input" name="perload_equipment_name_input">
                </form>
                
                <div class="container">
                    <b><label for="" id="load_summary_text"></label></b>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                            <label for="perload_rent_start_date" class="col-form-label">Load Quantity</label>
                            <input type="number" class="form-control" id="perload_input"   style="background:transparent; border:none; border-bottom:1px solid #3B3E4B; border-radius:1px !important; text-align:center; font-size:1.3rem;" placeholder="Load qty">
                            </div>
                        </div>
                        
                    </div>
                </div>
             
            </div>
            <div class="modal-footer">
                <h5 id="load_total" style="margin-right: 15% !important; text-decoration: underline;"></h5>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" id="perload_btn" class="btn" style="background-color: #E88A1A !important;">Rent</button>
            </div>
        </div>
    </div>
</div>
