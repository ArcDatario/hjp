<div class="modal fade" id="userModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="update_profile.php" method="post" enctype="multipart/form-data" id="update_user_form">
        <?php
include "conn.php";

$sql = "SELECT * FROM users_acc where id=" . $_SESSION['user_id'];

$result = $conn->query($sql);
$i = 1;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
  
        ?>
        <div class="form-group" style="margin-left:35%;">
           <img src="../user_images/<?php echo $row['image']; ?>" alt="" id="latest_image" height="100" width="100" id="image" style="border-radius:15px;">
          <br>
          <input type="file" id="new_file_image" name="new_image" accept="image/*">

            </div>

          <div class="form-group">
            <label for="username" class="col-form-label">Username:</label>
            <input type="text" class="form-control" id="username" name="user_name" value="<?php echo $row['user_name']; ?>">
          </div>

          <div class="form-group">
            <label for="phone" class="col-form-label">Phone #:</label>
            <input type="number" class="form-control" id="phone" name="phone" value="<?php echo $row['phone']; ?>">
          </div>

          <div class="form-group">
            <label for="email" class="col-form-label">Email:</label>
            <input type="text" class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>">
          </div>

          <div class="form-group">
            <label for="pass_word" class="col-form-label">Password (Optional if you want to change)</label>
            <input type="text" class="form-control" id="pass_word" name="pass_word">
            <input type="hidden" class="form-control" id="user_id" name="user_id" value="<?php echo $row['id']; ?>">
          </div>
          <div class="modal-footer">
          <a href="logout.php" class="btn btn-danger">Log out</a>  
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn" style="background:#E88A1A;">Save</button>
      </div>
 
      <?php
    }
} else {
    ?>
    <tr>
        <td colspan="4">No data found</td>
    </tr>
    <?php
}


?>     
        </form>
      </div>
      
    </div>
  </div>
</div>

<script>
    // Function to handle file input change event
    document.getElementById('new_file_image').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('latest_image').src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    });
</script>