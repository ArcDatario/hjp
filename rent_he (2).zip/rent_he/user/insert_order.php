<?php
session_start();

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $sand_id = $_POST['sand_id'];
    $user_id = $_POST['user_id'];
    $user_email = $_POST['user_email'];
    $order_summary = $_POST['order_summary'];
    $order_total = $_POST['order_total'];
    $bucket_input = $_POST['bucket_input'];
    $municipality = $_POST['municipality'];
    $barangay = $_POST['barangay'];
    $street = $_POST['street'];
    $sand_name = $_POST['sand_name'];

    include "conn.php";

    // Check if any of the input fields are empty
    if (empty($bucket_input) || empty($municipality) || empty($barangay) || empty($street)) {
        $_SESSION['empty_fields'] = true;
        header('location: index.php#sand');
        die();
    }

    $stmt = $conn->prepare("INSERT INTO orders (sand_id, user_id, user_email, summary, total, municipality, barangay, street, bucket,sand_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iississsis", $sand_id, $user_id, $user_email, $order_summary, $order_total, $municipality, $barangay, $street, $bucket_input, $sand_name);

    if ($stmt->execute()) {
        $_SESSION['order_success'] = true;
        header('location: index.php#sand');
        die();
    } else {
        $stmt->close();
        $conn->close();
    }
} else {
    $stmt->close();
    $conn->close();
}
?>
