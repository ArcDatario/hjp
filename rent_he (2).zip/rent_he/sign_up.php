<?php
// Start session
session_start();

// Establish connection to your database
include "conn.php";

function generateRandomNumber()
{
    return mt_rand(1, 50000);
}

// Assume you have received form data and sanitized it appropriately
$number = $_POST["phone"];
$user_name = $_POST["user_name"];
$email = $_POST["email"];
$pass_word = md5($_POST["password"]);

// Check if the number already exists in the database
$check_sql = "SELECT * FROM users_acc WHERE phone = '$number' AND email='$email' ";
$result = $conn->query($check_sql);

if ($result->num_rows > 0) {
    // Number already exists, return error response
    $response = [
        "status" => "error",
        "message" => "Number or E-mail already exists",
    ];
    echo json_encode($response);
    exit();
} else {
    $random_number = generateRandomNumber();
    // Rename the image file
    $new_image_name = "user_" . $random_number . ".jpg"; // Assuming the image format is PHP

    // Copy the default image file to the user_images folder
    $source_file = "user-icon.jpg";
    $target_dir = "user_images/";
    $target_file = $target_dir . $new_image_name;
    copy($source_file, $target_file);
    // Number does not exist, proceed with data insertion
    $sql =
        "INSERT INTO users_acc (user_name, phone, email, password, image) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssss",
        $user_name,
        $number,
        $email,
        $pass_word,
        $new_image_name
    );

    if ($stmt->execute()) {
        // Data insertion successful
        // Set session variable for user ID
        $_SESSION["user_id"] = $stmt->insert_id;

        // Fetch the inserted user's information from the database
        $select_sql = "SELECT * FROM users_acc WHERE id = {$_SESSION["user_id"]}";
        $result = $conn->query($select_sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            $_SESSION["user_id"] = $row["id"];
            $_SESSION["user_name"] = $row["user_name"];
            $_SESSION["user_number"] = $row["phone"];
            $_SESSION["user_email"] = $row["email"];
            $_SESSION["user_image"] = $row["image"];

            $_SESSION["logged_in"] = true;

            header("location: user/index.php");

            exit();
        } else {
            // Handle error if user data couldn't be fetched
            $response = [
                "status" => "error",
                "message" => "User data not found",
            ];
            echo json_encode($response);
            exit();
        }
    } else {
        // Handle error if data insertion fails
        $response = [
            "status" => "error",
            "message" => $stmt->error,
        ];
        echo json_encode($response);
        exit();
    }
}

// Close database connection
$stmt->close();
$conn->close();
?>
