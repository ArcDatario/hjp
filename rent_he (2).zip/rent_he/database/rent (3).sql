-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2024 at 07:37 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rent`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins_acc`
--

CREATE TABLE `admins_acc` (
  `id` int(11) NOT NULL,
  `user_name` text NOT NULL,
  `role` text NOT NULL,
  `password` text NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins_acc`
--

INSERT INTO `admins_acc` (`id`, `user_name`, `role`, `password`, `image`) VALUES
(5, 'arc', 'Owner', '909ba4ad2bda46b10aac3c5b7f01abd5', 'admin_15185.png'),
(6, 'admin', 'Staff', '21232f297a57a5a743894a0e4a801fc3', 'admin_11680.png');

-- --------------------------------------------------------

--
-- Table structure for table `equipment_tbl`
--

CREATE TABLE `equipment_tbl` (
  `id` int(11) NOT NULL,
  `equipment` text NOT NULL,
  `year_model` text NOT NULL,
  `capacity` text NOT NULL,
  `fuel` text NOT NULL,
  `kmperliter` text NOT NULL,
  `type` text NOT NULL,
  `category` text NOT NULL,
  `rate_per_day` int(11) NOT NULL,
  `image` text NOT NULL,
  `equipment_qty` int(11) DEFAULT NULL,
  `rate_category` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipment_tbl`
--

INSERT INTO `equipment_tbl` (`id`, `equipment`, `year_model`, `capacity`, `fuel`, `kmperliter`, `type`, `category`, `rate_per_day`, `image`, `equipment_qty`, `rate_category`) VALUES
(34, 'Volvo 3 ton Trucks', '2022', '3', 'Unleaded', '23', 'Automatic', 'Bulldozers', 1232, 'equipment_34675.jpg', -18, 'perHour'),
(35, 'Truck Loaded 1', '2022', '4', 'Diesel', '123', 'Manual', 'Bulldozers', 1235, 'equipment_10682.jpg', -26, 'perDay'),
(36, 'Mixer Heavy', '2021', '4', 'Diesel', '123', 'Manual', 'Mixers', 1234, 'equipment_34820.jpg', 6, 'perLoad'),
(37, ' Loader Goods', '2019', '1', 'Diesel', '5', 'Manual', 'Loaders', 2314, 'equipment_21963.webp', -2, 'perDay'),
(38, ' Heavy Machine', '2022', '3', 'Diesel', '5', 'Manual', 'Dump Trucks', 1321, 'equipment_16622.jpg', 13, 'perLoad'),
(39, 'Caterpillar Super Equip', '2016', '2', 'Unleaded', '4', 'Manual', 'Compactors', 2134, 'equipment_42555.jpg', -3, 'perHour');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks_tbl`
--

CREATE TABLE `feedbacks_tbl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `ratings` int(11) NOT NULL,
  `comments` text NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedbacks_tbl`
--

INSERT INTO `feedbacks_tbl` (`id`, `user_id`, `equipment_id`, `ratings`, `comments`, `date`) VALUES
(2, 54, 36, 5, 'The Caterpillar and Volvo loaders were sturdy and versatile, handling heavy loads with ease. The backhoe was responsive and versatile, while the bulldozer excelled in power and stability. Overall, a successful rental experience with reliable equipment.', '2024-05-07 13:38:23'),
(8, 54, 36, 4, 'The Caterpillar and Volvo loaders were sturdy and versatile, handling heavy loads with ease. The backhoe was responsive and versatile, while the bulldozer excelled in power and stability. Overall, a successful rental experience with reliable equipment.', '2024-05-07 14:02:24'),
(9, 54, 36, 5, 'The Caterpillar and Volvo loaders were sturdy and versatile, handling heavy loads with ease. The backhoe was responsive and versatile, while the bulldozer excelled in power and stability. Overall, a successful rental experience with reliable equipment.', '2024-05-07 14:53:15'),
(10, 54, 36, 1, 'The Caterpillar and Volvo loaders were sturdy and versatile, handling heavy loads with ease. The backhoe was responsive and versatile, while the bulldozer excelled in power and stability. Overall, a successful rental experience with reliable equipment.', '2024-05-07 14:56:37'),
(11, 54, 35, 4, 'The Caterpillar and Volvo loaders were sturdy and versatile, handling heavy loads with ease. The backhoe was responsive and versatile, while the bulldozer excelled in power and stability. Overall, a successful rental experience with reliable equipment.', '2024-05-07 15:11:05'),
(12, 54, 39, 5, 'The Caterpillar and Volvo loaders were sturdy and versatile, handling heavy loads with ease. The backhoe was responsive and versatile, while the bulldozer excelled in power and stability. Overall, a successful rental experience with reliable equipment.', '2024-05-12 10:05:20'),
(14, 54, 39, 5, 'The Caterpillar and Volvo loaders were sturdy and versatile, handling heavy loads with ease. The backhoe was responsive and versatile, while the bulldozer excelled in power and stability. Overall, a successful rental experience with reliable equipment.', '2024-05-12 10:06:25'),
(15, 54, 39, 3, 'The Caterpillar and Volvo loaders were sturdy and versatile, handling heavy loads with ease. The backhoe was responsive and versatile, while the bulldozer excelled in power and stability. Overall, a successful rental experience with reliable equipment.', '2024-05-12 10:06:31'),
(16, 54, 39, 5, 'The Caterpillar and Volvo loaders were sturdy and versatile, handling heavy loads with ease. The backhoe was responsive and versatile, while the bulldozer excelled in power and stability. Overall, a successful rental experience with reliable equipment.', '2024-05-12 10:06:44');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_email` text NOT NULL,
  `sand_id` int(11) NOT NULL,
  `sand_name` text DEFAULT NULL,
  `bucket` int(11) NOT NULL,
  `summary` text NOT NULL,
  `total` int(11) NOT NULL,
  `municipality` text NOT NULL,
  `barangay` text NOT NULL,
  `street` text NOT NULL,
  `status` text NOT NULL DEFAULT 'Pending',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `prepair_date` datetime DEFAULT NULL,
  `on_delivery_date` datetime DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `cancelled_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `user_email`, `sand_id`, `sand_name`, `bucket`, `summary`, `total`, `municipality`, `barangay`, `street`, `status`, `date`, `prepair_date`, `on_delivery_date`, `completed_date`, `cancelled_date`) VALUES
(129, 54, 'datarioarc@gmail.com', 4, 'Typical Sand', 4, '4 Buckets', 10000, 'Bansud', 'Poblacion', 'asdasdasdasdasdasd', 'Completed', '2024-05-15 00:20:54', '2024-05-15 00:22:06', '2024-05-15 00:23:05', '2024-05-15 00:23:52', NULL),
(130, 54, 'datarioarc@gmail.com', 3, 'Sand Gravel', 45, '45 Buckets', 67500, 'Bansud', 'Proper Tiguisan', 'asdasdasdasdasdasd', 'Completed', '2024-05-15 00:21:09', '2024-05-15 00:22:16', '2024-05-15 00:23:15', '2024-05-15 00:24:01', NULL),
(131, 54, 'datarioarc@gmail.com', 2, 'Crashed Sand', 63, '63 Buckets', 77742, 'Gloria', 'Malubay', 'asdasd asdasdasdasd', 'Completed', '2024-05-15 00:21:19', '2024-05-15 00:22:26', '2024-05-15 00:23:24', '2024-05-15 00:24:09', NULL),
(132, 54, 'datarioarc@gmail.com', 3, 'Sand Gravel', 76, '76 Buckets', 114000, 'Pinamalayan', 'Marfrancisco', 'asdasdasdasd asdasdada', 'Completed', '2024-05-15 00:21:28', '2024-05-15 00:22:35', '2024-05-15 00:23:32', '2024-05-15 00:24:19', NULL),
(133, 54, 'datarioarc@gmail.com', 4, 'Typical Sand', 4, '4 Buckets', 10000, 'Gloria', 'Macario Adriatico', 'asdasdasdasdasdas asdasdadasd', 'On Delivery', '2024-05-15 00:21:37', '2024-05-15 00:22:43', '2024-05-15 00:23:42', NULL, NULL),
(134, 54, 'datarioarc@gmail.com', 2, 'Crashed Sand', 4, '4 Buckets', 4936, 'Gloria', 'Malayong', 'asdasdasd asdasdasd', 'Pending', '2024-05-15 00:21:44', NULL, NULL, NULL, NULL),
(135, 54, 'datarioarc@gmail.com', 3, 'Sand Gravel', 4, '4 Buckets', 6000, 'Bansud', 'Pag-asa', 'asdasdasdasdasd', 'Cancelled', '2024-05-15 00:21:52', NULL, NULL, NULL, '2024-05-15 00:22:59'),
(136, 54, 'datarioarc@gmail.com', 4, 'Typical Sand', 4, '4 Buckets', 10000, 'Bansud', 'Poblacion', 'asdasdasdasd', 'Pending', '2024-05-15 00:21:59', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rental`
--

CREATE TABLE `rental` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `equipment_name` text NOT NULL,
  `rent_start_date` datetime NOT NULL,
  `rent_end_date` datetime NOT NULL,
  `status` text NOT NULL DEFAULT 'Pending',
  `approved_status` text DEFAULT NULL,
  `approved_date` datetime DEFAULT NULL,
  `paid_status` text DEFAULT NULL,
  `paid_date` datetime DEFAULT NULL,
  `total` int(11) NOT NULL,
  `summary` text NOT NULL,
  `equipment_load` int(11) DEFAULT NULL,
  `user_email` text NOT NULL,
  `date` datetime DEFAULT current_timestamp(),
  `return_status` text DEFAULT NULL,
  `return_date` datetime DEFAULT NULL,
  `completed_status` text DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `cancelled_status` text DEFAULT NULL,
  `cancelled_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rental`
--

INSERT INTO `rental` (`id`, `user_id`, `equipment_id`, `equipment_name`, `rent_start_date`, `rent_end_date`, `status`, `approved_status`, `approved_date`, `paid_status`, `paid_date`, `total`, `summary`, `equipment_load`, `user_email`, `date`, `return_status`, `return_date`, `completed_status`, `completed_date`, `cancelled_status`, `cancelled_date`) VALUES
(217, 54, 37, ' Loader Goods', '2024-05-11 00:00:00', '2024-05-12 00:00:00', 'Completed', 'Approved', '2024-05-11 10:39:40', 'Paid', '2024-05-11 10:42:02', 4628, '2 days', NULL, 'datarioarc@gmail.com', '2024-05-11 10:31:49', 'Returned', '2024-05-11 20:42:04', 'Completed', '2024-05-11 20:42:04', NULL, NULL),
(218, 54, 39, 'Caterpillar Super Equip', '2024-05-11 01:00:00', '2024-05-11 02:00:00', 'Completed', 'Approved', '2024-05-11 10:39:50', 'Paid', '2024-05-11 10:42:22', 2134, '1 hour', NULL, 'datarioarc@gmail.com', '2024-05-11 10:36:33', 'Returned', '2024-05-11 20:42:13', 'Completed', '2024-05-11 20:42:13', NULL, NULL),
(219, 54, 38, ' Heavy Machine', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Completed', 'Approved', '2024-05-11 10:40:01', 'Paid', '2024-05-11 10:42:30', 10568, '8 Loads', 8, 'datarioarc@gmail.com', '2024-05-11 10:37:12', 'Returned', '2024-05-12 10:07:21', 'Completed', '2024-05-12 10:07:21', NULL, NULL),
(220, 54, 35, 'Truck Loaded 1', '2024-05-11 00:00:00', '2024-05-12 00:00:00', 'Completed', 'Approved', '2024-05-11 10:40:13', 'Paid', '2024-05-11 10:42:42', 2470, '2 days', NULL, 'datarioarc@gmail.com', '2024-05-11 10:38:22', 'Returned', '2024-05-12 10:07:30', 'Completed', '2024-05-12 10:07:30', NULL, NULL),
(221, 54, 34, 'Volvo 3 ton Trucks', '2024-05-11 12:00:00', '2024-05-12 12:00:00', 'Completed', 'Approved', '2024-05-11 10:40:27', 'Paid', '2024-05-11 10:42:51', 29568, '24 hours', NULL, 'datarioarc@gmail.com', '2024-05-11 10:38:37', 'Returned', '2024-05-12 10:07:43', 'Completed', '2024-05-12 10:07:43', NULL, NULL),
(222, 54, 36, 'Mixer Heavy', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Completed', 'Approved', '2024-05-11 10:40:38', 'Paid', '2024-05-11 10:43:16', 4936, '4 Loads', 4, 'datarioarc@gmail.com', '2024-05-11 10:38:40', 'Returned', '2024-05-12 10:07:52', 'Completed', '2024-05-12 10:07:52', NULL, NULL),
(223, 54, 37, ' Loader Goods', '2024-05-13 00:00:00', '2024-05-14 00:00:00', 'Completed', 'Approved', '2024-05-11 10:40:49', 'Paid', '2024-05-11 10:43:26', 4628, '2 days', NULL, 'datarioarc@gmail.com', '2024-05-11 10:38:46', 'Returned', '2024-05-12 10:08:02', 'Completed', '2024-05-12 10:08:02', NULL, NULL),
(224, 54, 39, 'Caterpillar Super Equip', '2024-05-12 16:00:00', '2024-05-13 13:00:00', 'Completed', 'Approved', '2024-05-11 10:41:26', 'Paid', '2024-05-11 10:43:37', 44814, '21 hours', NULL, 'datarioarc@gmail.com', '2024-05-11 10:38:56', 'Returned', '2024-05-12 10:08:10', 'Completed', '2024-05-12 10:08:10', NULL, NULL),
(225, 54, 38, ' Heavy Machine', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Completed', 'Approved', '2024-05-11 10:41:34', 'Paid', '2024-05-11 10:43:52', 7926, '6 Loads', 6, 'datarioarc@gmail.com', '2024-05-11 10:38:59', 'Returned', '2024-05-12 10:08:44', 'Completed', '2024-05-12 10:08:44', NULL, NULL),
(226, 54, 34, 'Volvo 3 ton Trucks', '2024-05-13 12:00:00', '2024-05-14 12:00:00', 'Completed', 'Approved', '2024-05-10 10:41:44', 'Paid', '2024-05-10 10:44:02', 29568, '24 hours', NULL, 'datarioarc@gmail.com', '2024-05-10 10:39:06', 'Returned', '2024-05-12 10:13:53', 'Completed', '2024-05-12 10:13:53', NULL, NULL),
(227, 54, 36, 'Mixer Heavy', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Completed', 'Approved', '2024-05-10 10:41:53', 'Paid', '2024-05-10 10:44:11', 7404, '6 Loads', 6, 'datarioarc@gmail.com', '2024-05-10 10:39:12', 'Returned', '2024-05-12 10:13:59', 'Completed', '2024-05-12 10:13:59', NULL, NULL),
(228, 54, 35, 'Truck Loaded 1', '2024-05-12 00:00:00', '2024-05-13 00:00:00', 'Completed', 'Approved', '2024-05-12 10:08:22', 'Paid', '2024-05-12 10:08:32', 2470, '2 days', NULL, 'datarioarc@gmail.com', '2024-05-12 10:08:16', 'Returned', '2024-05-12 10:14:08', 'Completed', '2024-05-12 10:14:08', NULL, NULL),
(229, 54, 38, ' Heavy Machine', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Completed', 'Approved', '2024-05-12 10:14:25', 'Paid', '2024-05-12 10:14:35', 71334, '54 Loads', 54, 'datarioarc@gmail.com', '2024-05-12 10:08:59', 'Returned', '2024-05-12 10:14:43', 'Completed', '2024-05-12 10:14:43', NULL, NULL),
(230, 54, 39, 'Caterpillar Super Equip', '2024-05-14 02:00:00', '2024-05-14 07:00:00', 'Paid', 'Approved', '2024-05-14 21:56:03', 'Paid', '2024-05-14 21:56:13', 10670, '5 hours', NULL, 'datarioarc@gmail.com', '2024-05-14 21:55:34', NULL, NULL, NULL, NULL, NULL, NULL),
(231, 54, 36, 'Mixer Heavy', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Paid', 'Approved', '2024-05-14 22:12:29', 'Paid', '2024-05-14 22:13:35', 3702, '3 Loads', 3, 'datarioarc@gmail.com', '2024-05-14 21:58:22', NULL, NULL, NULL, NULL, NULL, NULL),
(232, 54, 38, ' Heavy Machine', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Cancelled', 'Approved', '2024-05-14 22:17:05', NULL, NULL, 17173, '13 Loads', 13, 'datarioarc@gmail.com', '2024-05-14 22:16:58', NULL, NULL, NULL, NULL, 'Cancelled', '2024-05-14 22:17:29'),
(233, 54, 38, ' Heavy Machine', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Pending', NULL, NULL, NULL, NULL, 30383, '23 Loads', 23, 'datarioarc@gmail.com', '2024-05-14 22:17:18', NULL, NULL, NULL, NULL, NULL, NULL),
(234, 54, 39, 'Caterpillar Super Equip', '2024-05-21 01:00:00', '2024-05-22 12:00:00', 'Pending', NULL, NULL, NULL, NULL, 74690, '35 hours', NULL, 'datarioarc@gmail.com', '2024-05-14 22:24:27', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sand_feedbacks`
--

CREATE TABLE `sand_feedbacks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sand_id` int(11) NOT NULL,
  `ratings` int(11) NOT NULL,
  `comments` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sand_tbl`
--

CREATE TABLE `sand_tbl` (
  `id` int(11) NOT NULL,
  `sand` text NOT NULL,
  `rate_per_bucket` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sand_tbl`
--

INSERT INTO `sand_tbl` (`id`, `sand`, `rate_per_bucket`, `image`) VALUES
(2, 'Crashed Sand', 1234, 'sand_32148.jpg'),
(3, 'Sand Gravel', 1500, 'sand_49787.jpg'),
(4, 'Typical Sand', 2500, 'sand_27295.webp');

-- --------------------------------------------------------

--
-- Table structure for table `search_tbl`
--

CREATE TABLE `search_tbl` (
  `id` int(11) NOT NULL,
  `category` text NOT NULL,
  `rate` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `search_tbl`
--

INSERT INTO `search_tbl` (`id`, `category`, `rate`, `date`) VALUES
(3, 'Backhoes', 2000, '2024-05-07 00:42:19'),
(4, 'Bulldozers', 2000, '2024-05-12 20:37:31'),
(5, 'Bulldozers', 1000, '2024-05-12 20:37:54'),
(6, 'Bulldozers', 1000, '2024-05-12 20:39:58'),
(7, 'Bulldozers', 1000, '2024-05-12 20:46:07'),
(8, 'Bulldozers', 1000, '2024-05-12 20:47:32'),
(9, 'Bulldozers', 1000, '2024-05-12 21:26:10'),
(10, 'Trenchers', 1000, '2024-05-12 23:22:30'),
(11, 'Compactors', 1000, '2024-05-12 23:22:37'),
(12, 'Compactors', 1000, '2024-05-12 23:22:42'),
(13, 'Excavators', 1000, '2024-05-12 23:22:45'),
(14, 'Forwarder', 1000, '2024-05-12 23:22:49'),
(15, 'Dump Trucks', 1000, '2024-05-12 23:22:52'),
(16, 'Backhoes', 1000, '2024-05-12 23:22:57'),
(17, 'Backhoes', 1000, '2024-05-12 23:23:00'),
(18, 'Backhoes', 1000, '2024-05-12 23:23:03'),
(19, 'Backhoes', 1000, '2024-05-12 23:55:30');

-- --------------------------------------------------------

--
-- Table structure for table `users_acc`
--

CREATE TABLE `users_acc` (
  `id` int(11) NOT NULL,
  `user_name` text NOT NULL,
  `phone` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_acc`
--

INSERT INTO `users_acc` (`id`, `user_name`, `phone`, `email`, `password`, `image`) VALUES
(54, 'arc', '09566320135', 'datarioarc@gmail.com', '909ba4ad2bda46b10aac3c5b7f01abd5', 'user_24776.png'),
(56, 'tae', '09123123123', 'datarioarc@gmail.com', '4752d51bd71f704beec34b798c76ca9e', 'user_48618.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins_acc`
--
ALTER TABLE `admins_acc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `equipment_tbl`
--
ALTER TABLE `equipment_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rental`
--
ALTER TABLE `rental`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sand_feedbacks`
--
ALTER TABLE `sand_feedbacks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sand_tbl`
--
ALTER TABLE `sand_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `search_tbl`
--
ALTER TABLE `search_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_acc`
--
ALTER TABLE `users_acc`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins_acc`
--
ALTER TABLE `admins_acc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `equipment_tbl`
--
ALTER TABLE `equipment_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `rental`
--
ALTER TABLE `rental`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;

--
-- AUTO_INCREMENT for table `sand_feedbacks`
--
ALTER TABLE `sand_feedbacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sand_tbl`
--
ALTER TABLE `sand_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `search_tbl`
--
ALTER TABLE `search_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users_acc`
--
ALTER TABLE `users_acc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
